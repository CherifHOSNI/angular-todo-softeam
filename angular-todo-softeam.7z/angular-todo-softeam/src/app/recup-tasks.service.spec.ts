import { TestBed } from '@angular/core/testing';

import { RecupTasksService } from './recup-tasks.service';

describe('RecupTasksService', () => {
  let service: RecupTasksService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecupTasksService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
