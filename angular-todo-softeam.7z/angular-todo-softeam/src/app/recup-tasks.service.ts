import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import   Tasks  from '../../server/db.json';


@Injectable({
  providedIn: 'root'
})
export class RecupTasksService {

  private tasks = Tasks;

  constructor(private http: HttpClient) {
  }

  public getJSON(): Observable<any> {
    //return this.tasks;
    return this.http.get('../server/db.json');
  }


}
