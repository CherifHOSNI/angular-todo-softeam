import { Component } from '@angular/core';
import {RecupTasksService} from './recup-tasks.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';

  constructor(private recupTasks : RecupTasksService){

  }

  ngOnInit(){
    let tasks = this.recupTasks.getJSON().subscribe(data => console.log(data));

  }

}

