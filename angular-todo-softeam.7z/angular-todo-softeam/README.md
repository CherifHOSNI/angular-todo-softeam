# TodoApp
Une application simple de gestion de tâches, une template html template.html est fournis pour faciliter l'integration du visuel.

## Règles de gestion:
- La tâche ne doit pas contenir des majuscules
- La taille minimale est de 15 caractères et maximale est de 120 caractères
- Si le champ est invalide, il faut mettre un contour rouge
- Le bouton "Save" ne doit être activé que si la tâche est valide
- Le bouton "Delete" sert à supprimer une tâche, on peut supprimer la tâche à tout moment
- Le bouton "Start" sert à changer l'état de la tâche de "Idle" vers "In progress"
- Le bouton "Finished" sert à changer l'état de la tâche de "In progress" vers "Done"
- Quand une tâche est "Done", il faut la barrer
- Quand le titre de la tache dépasse 80 caractères il faut afficher les 80 caractères + ...
